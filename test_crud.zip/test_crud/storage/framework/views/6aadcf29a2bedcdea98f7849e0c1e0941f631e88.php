 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 7 CRUD Rerritos</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('perritos.create')); ?>"> Crear usuario</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>N°</th>
            <th>Nombre</th>
            <th>Color</th>
            <th>Raza</th>            
            <th width="280px">Accion</th>
        </tr>
        <?php $__currentLoopData = $perritos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($perro->nombre); ?></td>
            <td><?php echo e($perro->color); ?></td>
            <td><?php echo e($perro->raza); ?></td>            
            <td>
                <form action="<?php echo e(route('perritos.destroy',$perro->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('perritos.show',$perro->id)); ?>">Ver</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('perritos.edit',$perro->id)); ?>">Editar</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $perritos->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('perritos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/crud-perritos/resources/views/perritos/index.blade.php ENDPATH**/ ?>