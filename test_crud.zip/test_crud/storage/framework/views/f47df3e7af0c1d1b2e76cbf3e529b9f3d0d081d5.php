  
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Agregar usuario</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('perritos.index')); ?>"> Volver</a>
        </div>
    </div>
</div>
 
<div class="alert alert-danger">
    <strong>!Ups!</strong> Problemas de envio.<br><br>
    <ul id="errores">   

    </ul>
</div>
 
<form method="POST" enctype="multipart/form-data" id="upload_image_form" action="javascript:void(0)" >
                  
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                <input type="text" name="nombre" id="nombre" class="form-control" placeholder="Nombre">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Color:</strong>
                <input type="text" class="form-control"  name="color" id="color" placeholder="Color">
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Raza:</strong>
                <input type="text" class="form-control"   name="raza" id="raza" placeholder="Raza">
            </div>
        </div>
      
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <input type="file" name="image" placeholder="Choose image" id="image">                   
            </div>
        </div>              
              
        <div class="col-xs-12 col-sm-12 col-md-12">
            <button type="submit" class="btn btn-primary">Crear usuario</button>
        </div>
    </div>     
</form>
<script type="text/javascript">
    $(document).ready(function() {

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#upload_image_form').submit(function() {

            var nombre =  $.trim($('#nombre').val());
            var color =  $.trim($('#color').val());
            var raza =  $.trim($('#raza').val());
            var formData = new FormData(this);

            formData.append('nombre', nombre) ;
            formData.append('color', color);
            formData.append('raza', raza);

            // Código por si se necesita validar por el lado del cliente

            /*var validar = 1;
            var texto_alert = '';
             
            if(!nombre){
                texto_alert += "<li> Falta nombre </li>";
                validar = 0;
            }
            if(!color){
                texto_alert += " <li>Falta color </li>";
                validar = 0;
            }      
            if(!raza){
                texto_alert += "<li> Falta raza </li>";
                validar = 0;
            }
            if(!validar){
                alert(texto_alert);
                return
            }*/

            $.ajax({
                type:'POST',
                url: "/perritos",
                data: formData,
                cache:false,
                contentType: false,
                processData: false,
                success: (data) => {
                    alert('Usuario creado con éxito');
                    $(".alert-danger").hide();                    
                    window.location.replace("/perritos");
                },
                error: function(data){
                    $("#errores").html(""); 
                    var html = '';
                    $.each(data.responseJSON.errors,function(k, v){ 
                        if(k == 'image'){
                            $.each(v,function(k2, v2){                  
                                html += '<li>' + v2 + '</li>';
                            });
                        }else{
                            html += '<li>' + v + '</li>';                           
                        }
                    });
                    $("#errores").append(html);
                    $(".alert-danger").show();
                     
                }
            });
        });

    });
</script>
<style type="text/css">
    .alert-danger{
        display: none;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('perritos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/crud-perritos/resources/views/perritos/create.blade.php ENDPATH**/ ?>