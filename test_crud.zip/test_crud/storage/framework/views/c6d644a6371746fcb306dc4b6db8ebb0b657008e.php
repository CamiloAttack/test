<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Usuario</h2>
            </div>         
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('perritos.index')); ?>"> Volver</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                <?php echo e($usuario->nombre); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Color:</strong>
                <?php echo e($usuario->color); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Raza:</strong>
                <?php echo e($usuario->raza); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <img src="<?php echo e(asset('/images/')); ?>/<?php echo e($usuario->imagen); ?>" width=" 300">
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('perritos.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/crud-perritos/resources/views/perritos/show.blade.php ENDPATH**/ ?>