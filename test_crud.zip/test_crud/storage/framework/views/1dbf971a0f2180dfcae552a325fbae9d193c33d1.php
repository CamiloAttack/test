<!DOCTYPE html>
<html>
<head>
    <title>Laravel 7 CRUD Usuarios</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha/css/bootstrap.css" rel="stylesheet">
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
<body>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH /var/www/html/LARAVEL/crud-perritos/resources/views/perritos/layout.blade.php ENDPATH**/ ?>