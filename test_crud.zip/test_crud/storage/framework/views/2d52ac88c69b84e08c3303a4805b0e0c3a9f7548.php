<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Usuario</h2>
            </div>         
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('usuarios.index')); ?>"> Volver</a>
            </div>
        </div>
    </div>
   
    <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Nombre:</strong>
                <?php echo e($usuario->nombre); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Apellido:</strong>
                <?php echo e($usuario->apellido); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Rut:</strong>
                <?php echo e($usuario->rut); ?>

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <img src="<?php echo e(asset('/images/')); ?>/<?php echo e($usuario->imagen); ?>" width=" 300">
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('usuarios.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/test_crud/resources/views/usuarios/show.blade.php ENDPATH**/ ?>