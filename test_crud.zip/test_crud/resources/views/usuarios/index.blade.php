@extends('usuarios.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 7 CRUD Usuarios           <br></h2>
            </div>
            <div class="pull-right">


                <a class="btn btn-success" href="{{ route('usuarios.create') }}"> Crear  usuario</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
                                    
    <table class="table table-bordered">
        <tr>
            <th>N°</th>
            <th>Nombre</th>
            <th>Color</th>
            <th>Raza</th>            
            <th width="280px">Accion </th>
        </tr>
        @foreach ($usuarios as $perro)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $perro->nombre }}</td>
            <td>{{ $perro->color }}</td>
            <td>{{ $perro->raza }}</td>            
            <td>
                <form action="{{ route('usuarios.destroy',$perro->id) }}" method="POST">
 
                    <a class="btn btn-info carga-iframe" data-toggle="modal" data-target="#myModal" data-iframe="{{ route('usuarios.show',$perro->id) }}" >Ver</a>
                    
                    <a class="btn btn-primary carga-iframe" data-toggle="modal" data-target="#myModal"  data-iframe="{{ route('usuarios.edit',$perro->id) }}">Editar</a>
                                        <a class="btn btn-primary "   href="{{ route('usuarios.edit',$perro->id) }}">Editar</a>

   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Eliminar</button>

                </form>
            </td>
        </tr>
        @endforeach
    </table>
  <!-- Button to Open the Modal -->


<!-- The Modal -->
<div class="modal" id="myModal" aria-labelledby="myLargeModalLabel" >
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
        <div class="embed-responsive embed-responsive-16by9">
          <iframe id="iframe" class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
        </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
 
    {!! $usuarios->links() !!}
      
@endsection