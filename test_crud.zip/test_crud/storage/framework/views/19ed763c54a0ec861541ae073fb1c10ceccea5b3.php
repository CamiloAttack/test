 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 7 CRUD Usuarios           <br></h2>
            </div>
            <div class="pull-right">


                <a class="btn btn-success" href="<?php echo e(route('usuarios.create')); ?>"> Crear  usuario</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
                                    
    <table class="table table-bordered">
        <tr>
            <th>N°</th>
            <th>Nombre</th>
            <th>Color</th>
            <th>Raza</th>            
            <th width="280px">Accion </th>
        </tr>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($perro->nombre); ?></td>
            <td><?php echo e($perro->color); ?></td>
            <td><?php echo e($perro->raza); ?></td>            
            <td>
                <form action="<?php echo e(route('usuarios.destroy',$perro->id)); ?>" method="POST">
 
                    <a class="btn btn-info carga-iframe" data-toggle="modal" data-target="#myModal" data-iframe="<?php echo e(route('usuarios.show',$perro->id)); ?>" >Ver</a>
                    
                    <a class="btn btn-primary carga-iframe" data-toggle="modal" data-target="#myModal"  data-iframe="<?php echo e(route('usuarios.edit',$perro->id)); ?>">Editar</a>
                                        <a class="btn btn-primary "   href="<?php echo e(route('usuarios.edit',$perro->id)); ?>">Editar</a>

   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Eliminar</button>

                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  <!-- Button to Open the Modal -->


<!-- The Modal -->
<div class="modal" id="myModal" aria-labelledby="myLargeModalLabel" >
  <div class="modal-dialog modal-lg" >
    <div class="modal-content">

      <!-- Modal Header -->
      <div class="modal-header">
        <h4 class="modal-title">Modal Heading</h4>
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>

      <!-- Modal body -->
        <div class="embed-responsive embed-responsive-16by9">
          <iframe id="iframe" class="embed-responsive-item" src="https://www.youtube.com/embed/zpOULjyy-n8?rel=0" allowfullscreen></iframe>
        </div>

      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
      </div>

    </div>
  </div>
</div>
 
    <?php echo $usuarios->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('usuarios.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/LARAVEL/test_crud/resources/views/usuarios/index.blade.php ENDPATH**/ ?>